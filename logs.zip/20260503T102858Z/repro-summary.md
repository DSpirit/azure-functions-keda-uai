# Functions on ACA - Sanitized Repro Bundle

- Resource group: <RESOURCE_GROUP>
- Container app: <CONTAINER_APP>
- Deployment name: <DEPLOYMENT_NAME>
- Observation: Azure Functions on ACA does not auto-create queue scaler rules (`scaleRules` is null).

## Included files

- containerapp_show.json
- containerapp_scale_and_env.json
- containerapp_revisions.json
- containerapp_logs_tail300.txt
- deployment_main.json

All identifiers and hostnames are redacted for safe sharing.
